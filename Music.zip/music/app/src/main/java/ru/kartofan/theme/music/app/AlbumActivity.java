package ru.kartofan.theme.music.app;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.*;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.util.regex.*;
import java.text.*;
import org.json.*;
import java.util.ArrayList;
import java.util.HashMap;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.content.Intent;
import android.net.Uri;
import android.app.Activity;
import android.content.SharedPreferences;
import java.util.Timer;
import java.util.TimerTask;
import android.widget.AdapterView;
import android.view.View;
import com.bumptech.glide.Glide;
import android.graphics.Typeface;

import com.google.android.material.appbar.SubtitleCollapsingToolbarLayout;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.DialogFragment;

public class AlbumActivity extends  AppCompatActivity  { 
	
	private Timer _timer = new Timer();
	
	private String str = "";
	private String str1 = "";
	private String about = "";
	private double myster = 0;
	private double explicit = 0;
	private double pos = 0;
	
	private ArrayList<HashMap<String, Object>> map = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> play = new ArrayList<>();
	
	private LinearLayout linear2;
	private LinearLayout linear5;
	private TextView tale;
	private ListView listview1;
	private LinearLayout linear4;
	private ImageView imageview1;
	private TextView name;
	private TextView artist;
	private TextView release;
	private TextView date;
	private TextView time;
	private TextView copyright;
	private TextView textview1;
	
	private Intent i = new Intent();
	private SharedPreferences sp;
	private TimerTask t;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.album);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		linear5 = (LinearLayout) findViewById(R.id.linear5);
		tale = (TextView) findViewById(R.id.tale);
		listview1 = (ListView) findViewById(R.id.listview1);
		linear4 = (LinearLayout) findViewById(R.id.linear4);
		imageview1 = (ImageView) findViewById(R.id.imageview1);
		name = (TextView) findViewById(R.id.name);
		artist = (TextView) findViewById(R.id.artist);
		release = (TextView) findViewById(R.id.release);
		date = (TextView) findViewById(R.id.date);
		time = (TextView) findViewById(R.id.time);
		copyright = (TextView) findViewById(R.id.copyright);
		textview1 = (TextView) findViewById(R.id.textview1);
		sp = getSharedPreferences("sp", Activity.MODE_PRIVATE);
		
		tale.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (about.length() > 110) {
					final com.google.android.material.bottomsheet.BottomSheetDialog bs_base = new com.google.android.material.bottomsheet.BottomSheetDialog(AlbumActivity.this);
					bs_base.setCancelable(true);
					View layBase = getLayoutInflater().inflate(R.layout.bottom, null);
					bs_base.setContentView(layBase);
					
					TextView text = (TextView)
					layBase.findViewById(R.id.text);
					text.setText(map.get((int)0).get("tale").toString());
					text.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/sfl.ttf"), Typeface.NORMAL);
					
					TextView about = (TextView)
					layBase.findViewById(R.id.about);

					about.setVisibility(View.GONE);
					
					bs_base.show();
				}
				else {
					
				}
			}
		});
		
		listview1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				if (play.get((int)_position).containsKey("mystery")) {

				}
				else {
					if (sp.getString("explicit", "").equals("no")) {
						if (play.get((int)_position).get("explicit").toString().equals("yes")) {
							com.google.android.material.snackbar.Snackbar.make(listview1, "This song not for children!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("Ok", new View.OnClickListener(){
								@Override
								public void onClick(View _view) {

								}
							}).show();
						}
						else {
							if (play.get((int)_position).containsKey("link")) {
								i.setClass(getApplicationContext(), MusicActivity.class);
								i.putExtra("link", play.get((int)_position).get("link").toString());
								startActivity(i);
							}
							else {
								com.google.android.material.snackbar.Snackbar.make(listview1, "This song is unavailable to play!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("Ok", new View.OnClickListener(){
									@Override
									public void onClick(View _view) {

									}
								}).show();
							}
						}
					}
					else {
						if (play.get((int)_position).containsKey("link")) {
							i.setClass(getApplicationContext(), MusicActivity.class);
							i.putExtra("link", play.get((int)_position).get("link").toString());
							startActivity(i);
						}
						else {
							com.google.android.material.snackbar.Snackbar.make(listview1, "This song is unavailable to play!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("Ok", new View.OnClickListener(){
								@Override
								public void onClick(View _view) {

								}
							}).show();
						}
					}
				}
			}
		});
		
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setClass(getApplicationContext(), ImageActivity.class);
				i.putExtra("imageq", map.get((int)0).get("image").toString());
				startActivity(i);
			}
		});
	}
	
	private void initializeLogic() {
		new BackTask().execute(getIntent().getStringExtra("link"));
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}

	@Override
	public void onBackPressed() {
		finish();
	}

	public void _extra () {
	}
	
	private class BackTask extends AsyncTask<String, Integer, String> {
		
		@Override
		
		protected void onPreExecute() {}
		
		
		protected String doInBackground(String... address) {
			
			String output = "";
			
			try {
				
				java.net.URL url = new java.net.URL(address[0]);
				
				java.io.BufferedReader in = new java.io.BufferedReader(new java.io.InputStreamReader(url.openStream()));
				
				String line;
				
				while ((line = in.readLine()) != null) {
					
					output += line;
					
				}
				
				in.close(); } catch (java.net.MalformedURLException e) {
				
				output = e.getMessage();
				
			} catch (java.io.IOException e) {
				
				output = e.getMessage();
				
			} catch (Exception e) {
				
				output = e.toString();
				
			}
			
			return output;
			
		}
		
		
		protected void onProgressUpdate(Integer... values) {}
		
		
		protected void onPostExecute(String s){
			str = s;
			map = new Gson().fromJson(str, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
			_text();
		}
	}
	
	
	public void _marquee (final TextView _textview, final String _text) {
		
		_textview.setText(_text);
		_textview.setSingleLine(true);
		_textview.setEllipsize(TextUtils.TruncateAt.MARQUEE);
		_textview.setSelected(true);
	}

	public void _marquee1 (final TextView _textview, final String _text) {

		_textview.setText(_text);
		_textview.setMaxLines(2);
		_textview.setEllipsize(TextUtils.TruncateAt.END);
		_textview.setSelected(true);
	}
	
	public void _extra1 () {
	}
	
	private class BackTask1 extends AsyncTask<String, Integer, String> {
		
		@Override
		
		protected void onPreExecute() {}
		
		
		protected String doInBackground(String... address) {
			
			String output = "";
			
			try {
				
				java.net.URL url = new java.net.URL(address[0]);
				
				java.io.BufferedReader in = new java.io.BufferedReader(new java.io.InputStreamReader(url.openStream()));
				
				String line;
				
				while ((line = in.readLine()) != null) {
					
					output += line;
					
				}
				
				in.close(); } catch (java.net.MalformedURLException e) {
				
				output = e.getMessage();
				
			} catch (java.io.IOException e) {
				
				output = e.getMessage();
				
			} catch (Exception e) {
				
				output = e.toString();
				
			}
			
			return output;
			
		}
		
		
		protected void onProgressUpdate(Integer... values) {}
		
		
		protected void onPostExecute(String s1){
			str1 = s1;
			play = new Gson().fromJson(str1, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
			pos = 0;
			for(int _repeat51 = 0; _repeat51 < (int)(play.size()); _repeat51++) {
				if (play.get((int)pos).containsKey("mystery")) {
					myster++;
				}
				if (play.get((int)pos).get("explicit").toString().equals("yes")) {
					explicit++;
				}
				pos++;
			}
			listview1.setAdapter(new Listview1Adapter(play));
			if (sp.getString("explicit", "").equals("no")){
			_ViewSetHeight(listview1, (play.size() * SketchwareUtil.getDip(getApplicationContext(), (int)(51))) - ((myster * SketchwareUtil.getDip(getApplicationContext(), (int)(25))) + (explicit * SketchwareUtil.getDip(getApplicationContext(), (int)(51)))));
			} else {
				_ViewSetHeight(listview1, (play.size() * SketchwareUtil.getDip(getApplicationContext(), (int) (51))) - (myster * SketchwareUtil.getDip(getApplicationContext(), (int) (25))));
			}
			((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
			time.setText(map.get((int)0).get("songs").toString().concat(" songs, ".concat(map.get((int)0).get("time").toString())));
			tale.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/sfl.ttf"), Typeface.NORMAL);
		}
	}
	
	
	public void _text () {
		if (map.get((int)0).containsKey("tale")) {
			tale.setVisibility(View.VISIBLE);
			about = map.get((int)0).get("tale").toString();
			if (about.length() > 110) {
				_marquee1(tale, map.get((int)0).get("tale").toString());
			}
			else {
				tale.setText(map.get((int)0).get("tale").toString());
			}
		}
		else {
			tale.setVisibility(View.GONE);
		}
		_marquee(name, map.get((int)0).get("name").toString());
		_marquee(artist, map.get((int)0).get("artist").toString());
		sp.edit().putString("artist", map.get((int)0).get("artist").toString()).commit();
		_marquee(release, map.get((int)0).get("genre").toString().concat(" • ".concat(map.get((int)0).get("release").toString())));
		date.setText(map.get((int)0).get("date").toString());
		copyright.setText(map.get((int)0).get("copyright").toString());
		Toolbar toolbar = findViewById(R.id.toolbar);
		setSupportActionBar(toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_arrow_back);
		final SubtitleCollapsingToolbarLayout subtitleCollapsingToolbarLayout = findViewById(R.id.toolbar_layout);
		subtitleCollapsingToolbarLayout.setTitle(map.get((int)0).get("name").toString());
		subtitleCollapsingToolbarLayout.setSubtitle(map.get((int)0).get("artist").toString().concat(" • ".concat(map.get((int)0).get("genre").toString().concat(" • ".concat(map.get((int)0).get("release").toString())))));
		Glide.with(getApplicationContext()).load(Uri.parse(map.get((int)0).get("image").toString())).into(imageview1);
		if (sp.getString("video", "").equals("yes")) {
			Glide.with(getApplicationContext()).load(Uri.parse(map.get((int)0).get("video").toString())).into(imageview1);
		}
		name.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/sfm.ttf"), Typeface.BOLD);
		artist.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/sfl.ttf"), Typeface.NORMAL);
		release.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/sfl.ttf"), Typeface.NORMAL);
		date.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/sfl.ttf"), Typeface.NORMAL);
		copyright.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/sfl.ttf"), Typeface.NORMAL);
		new BackTask1().execute(getIntent().getStringExtra("songs"));
		t = new TimerTask() {
			@Override
			public void run() {
				runOnUiThread(new Runnable() {
					@Override
					public void run() {
						//_roundImageView(imageview1, 30);
					}
				});
			}
		};
		_timer.schedule(t, (int)(600));
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		MenuInflater inflater = getMenuInflater();
		inflater.inflate(R.menu.artist, menu);
		return true;
	}
	@Override
	public boolean onOptionsItemSelected(@NonNull MenuItem item){
		if (item.getItemId()==android.R.id.home){
			finish();
		}
		return super.onOptionsItemSelected(item);
	}
	public void _CornerRadius (final View _view, final String _color, final double _RT, final double _LT, final double _RB, final double _LB) {
		android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
		gd.setColor(Color.parseColor(_color));
		gd.setCornerRadii(new float[] { (float)_LT, (float)_LT, (float)_RT, (float)_RT, (float)_RB, (float)_RB, (float)_LB, (float)_LB });
		_view.setBackground(gd);
	}
	
	
	public void _corner (final View _view, final double _radius) {
		android.graphics.drawable.GradientDrawable ab = new android.graphics.drawable.GradientDrawable();
		ab.setCornerRadius((float) _radius);
		_view.setBackground(ab);
	}
	
	
	public void _roundImageView (final ImageView _Imageview, final double _round) {
		Bitmap bm = ((android.graphics.drawable.BitmapDrawable)_Imageview.getDrawable()).getBitmap();
		
		_Imageview.setImageBitmap(getRoundedCornerBitmap(bm, ((int)_round)));
		
	}
	public static Bitmap getRoundedCornerBitmap(Bitmap bitmap, int pixels) {
		Bitmap output = Bitmap.createBitmap(bitmap.getWidth(), bitmap.getHeight(), Bitmap.Config.ARGB_8888);
		Canvas canvas = new Canvas(output);
		final int color = 0xff424242;
		final Paint paint = new Paint();
		final Rect rect = new Rect(0, 0, bitmap.getWidth(), bitmap.getHeight());
		final RectF rectF = new RectF(rect);
		final float roundPx = pixels;
		paint.setAntiAlias(true);
		canvas.drawARGB(0, 0, 0, 0);
		paint.setColor(color);
		canvas.drawRoundRect(rectF, roundPx, roundPx, paint); 
		paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN)); 
		canvas.drawBitmap(bitmap, rect, rect, paint);
		return output;
	}

	private void _ViewSetHeight(final View _view, final double _num) {
		_view.getLayoutParams().height=(int)(_num);
	}
	
	public class Listview1Adapter extends BaseAdapter {
		ArrayList<HashMap<String, Object>> _data;
		public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = (LayoutInflater)getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.songs, null);
			}

			final LinearLayout tale = (LinearLayout) _view.findViewById(R.id.tale);
			final LinearLayout linear1 = (LinearLayout) _view.findViewById(R.id.linear1);
			final ImageView imageview1 = (ImageView) _view.findViewById(R.id.imageview1);
			final ImageView imageview2 = (ImageView) _view.findViewById(R.id.imageview2);
			final TextView number = (TextView) _view.findViewById(R.id.number);
			final TextView mystery = (TextView) _view.findViewById(R.id.mystery);
			final TextView time = (TextView) _view.findViewById(R.id.time);
			final LinearLayout linear2 = (LinearLayout) _view.findViewById(R.id.linear2);
			final TextView name = (TextView) _view.findViewById(R.id.name);
			final TextView artist = (TextView) _view.findViewById(R.id.artist);
			_ViewSetHeight(listview1, (play.size() * SketchwareUtil.getDip(getApplicationContext(), (int)(51))) - (myster * SketchwareUtil.getDip(getApplicationContext(), (int)(18))));
			if (play.get((int)_position).containsKey("mystery")) {
				linear1.setVisibility(View.GONE);
				tale.setVisibility(View.VISIBLE);
				mystery.setText(play.get((int)_position).get("mystery").toString());
				mystery.setTypeface(Typeface.createFromAsset(getAssets(), "fonts/sfm.ttf"), Typeface.BOLD);
				myster = myster +1;
				sp.edit().putString("myster",String.valueOf((long) (myster))).commit();
			} else {
				linear1.setVisibility(View.VISIBLE);
				tale.setVisibility(View.GONE);
				number.setText(play.get((int) _position).get("number").toString());
				time.setText(play.get((int) _position).get("time").toString());
				_marquee(name, play.get((int) _position).get("name").toString());
				_marquee(artist, play.get((int) _position).get("artist").toString());
				if (play.get((int) _position).get("star").toString().equals("yes")) {
					imageview1.setVisibility(View.VISIBLE);
				} else {
					imageview1.setVisibility(View.GONE);
				}
				if (play.get((int) _position).get("explicit").toString().equals("yes")) {
					imageview2.setVisibility(View.VISIBLE);
				} else {
					imageview2.setVisibility(View.GONE);
				}
				if (play.get((int) _position).get("artist").toString().equals(sp.getString("artist", ""))) {
					artist.setVisibility(View.GONE);
				} else {
					artist.setVisibility(View.VISIBLE);
				}
				if (sp.getString("explicit", "").equals("no")){
					if (play.get((int)_position).get("explicit").toString().equals("yes")) {
						explicit = explicit +1;
						number.setTextColor(getResources().getColor(R.color.text4));
					  name.setTextColor(getResources().getColor(R.color.text4));
					  artist.setTextColor(getResources().getColor(R.color.text4));
					  time.setTextColor(getResources().getColor(R.color.text4));
					  imageview1.setColorFilter(getResources().getColor(R.color.text4));
					  imageview2.setColorFilter(getResources().getColor(R.color.text4));
					} else {
						number.setTextColor(getResources().getColor(R.color.text1));
						name.setTextColor(getResources().getColor(R.color.text1));
						artist.setTextColor(getResources().getColor(R.color.text1));
						time.setTextColor(getResources().getColor(R.color.text1));
						imageview1.setColorFilter(getResources().getColor(R.color.text1));
						imageview2.setColorFilter(getResources().getColor(R.color.text1));
					}
				}
				if (sp.getString("explicit_songs", "").equals("no")){
					if (play.get((int)_position).get("explicit").toString().equals("yes")) {
						linear1.setVisibility(View.GONE);
					} else {
						linear1.setVisibility(View.VISIBLE);
					}
				}
				number.setTypeface(Typeface.createFromAsset(getAssets(), "fonts/sfm.ttf"), Typeface.BOLD);
				time.setTypeface(Typeface.createFromAsset(getAssets(), "fonts/sfm.ttf"), Typeface.NORMAL);
				name.setTypeface(Typeface.createFromAsset(getAssets(), "fonts/sfm.ttf"), Typeface.BOLD);
				artist.setTypeface(Typeface.createFromAsset(getAssets(), "fonts/sfl.ttf"), Typeface.NORMAL);
			}
			if (sp.getString("explicit_songs", "").equals("no")) {
				_ViewSetHeight(listview1, (play.size() * SketchwareUtil.getDip(getApplicationContext(), (int)(51))) - ((myster * SketchwareUtil.getDip(getApplicationContext(), (int)(18))) + (explicit * SketchwareUtil.getDip(getApplicationContext(), (int)(51)))));
			} else {
				_ViewSetHeight(listview1, (play.size() * SketchwareUtil.getDip(getApplicationContext(), (int) (51))) - (myster * SketchwareUtil.getDip(getApplicationContext(), (int) (18))));
			}
			return _view;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
