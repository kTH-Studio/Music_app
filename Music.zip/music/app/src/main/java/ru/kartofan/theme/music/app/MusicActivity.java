package ru.kartofan.theme.music.app;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.*;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.util.regex.*;
import java.text.*;
import org.json.*;
import java.util.ArrayList;
import java.util.HashMap;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;

import androidx.core.app.NotificationCompat;
import androidx.recyclerview.widget.*;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;
import android.widget.SeekBar;
import android.media.MediaPlayer;
import java.util.Timer;
import java.util.TimerTask;
import android.content.Intent;
import android.net.Uri;
import android.view.View;
import android.widget.AdapterView;
import com.bumptech.glide.Glide;
import android.graphics.Typeface;
import java.text.DecimalFormat;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.DialogFragment;

public class MusicActivity extends  AppCompatActivity  {
	
	private Timer _timer = new Timer();
	
	private String str = "";
	private String currentfile = "";
	private double song_duration = 0;
	private double pos = 0;
	private String text = "";
	private String pos1 = "";
	private double time = 0;
	private double current = 0;
	private double smoothScroller = 0;
	private String str1 = "";
	private double play1 = 0;
	private String str2 = "";
	private double tr = 0;
	
	private ArrayList<HashMap<String, Object>> map = new ArrayList<>();
	private ArrayList<String> n = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> play = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> artists = new ArrayList<>();
	
	private LinearLayout linear1;
	private LinearLayout linear8;
	private TextView textview5;
	private LinearLayout linear11;
	private ImageView imageview6;
	private LinearLayout linear14;
	private LinearLayout linear2;
	private ProgressBar progressbar1;
	private ProgressBar progressbar2;
	private ListView listview3;
	private RecyclerView recyclerview1;
	private ImageView imageview1;
	private LinearLayout linear3;
	private ImageView imageview2;
	private TextView textview1;
	private TextView textview2;
	private SeekBar seekbar2;
	private LinearLayout linear10;
	private LinearLayout linear9;
	private TextView textview6;
	private TextView textview3;
	private TextView textview4;
	private ImageView imageview7;
	private LinearLayout linear15;
	private ImageView imageview3;
	private ImageView imageview4;
	private ImageView imageview5;
	
	private MediaPlayer raine;
	private MediaPlayer raone;
	private TimerTask t;
	private MediaPlayer mp;
	private TimerTask c;
	private TimerTask x;
	private TimerTask s;
	private TimerTask a;
	private Notification notif;
	private Intent i = new Intent();
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.music);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		linear8 = (LinearLayout) findViewById(R.id.linear8);
		textview5 = (TextView) findViewById(R.id.textview5);
		linear11 = (LinearLayout) findViewById(R.id.linear11);
		imageview6 = (ImageView) findViewById(R.id.imageview6);
		linear14 = (LinearLayout) findViewById(R.id.linear14);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		progressbar1 = (ProgressBar) findViewById(R.id.progressbar1);
		progressbar2 = (ProgressBar) findViewById(R.id.progressbar2);
		listview3 = (ListView) findViewById(R.id.listview3);
		recyclerview1 = (RecyclerView) findViewById(R.id.recyclerview1);
		imageview1 = (ImageView) findViewById(R.id.imageview1);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		imageview2 = (ImageView) findViewById(R.id.imageview2);
		textview1 = (TextView) findViewById(R.id.textview1);
		textview2 = (TextView) findViewById(R.id.textview2);
		seekbar2 = (SeekBar) findViewById(R.id.seekbar2);
		linear10 = (LinearLayout) findViewById(R.id.linear10);
		linear9 = (LinearLayout) findViewById(R.id.linear9);
		textview6 = (TextView) findViewById(R.id.textview6);
		textview3 = (TextView) findViewById(R.id.textview3);
		textview4 = (TextView) findViewById(R.id.textview4);
		linear15 = (LinearLayout) findViewById(R.id.linear15);
		imageview3 = (ImageView) findViewById(R.id.imageview3);
		imageview4 = (ImageView) findViewById(R.id.imageview4);
		imageview5 = (ImageView) findViewById(R.id.imageview5);
		
		imageview6.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (map.get((int)0).containsKey("text")) {
					imageview6.setVisibility(View.GONE);
					imageview1.setVisibility(View.VISIBLE);
					recyclerview1.setVisibility(View.VISIBLE);
					listview3.setVisibility(View.VISIBLE);
					linear11.setVisibility(View.GONE);
					linear14.setVisibility(View.GONE);
				}
			}
		});
		
		linear2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_bottom();
			}
		});
		
		listview3.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				if (play.get((int)_position).get("text").toString().equals("!")) {
					i.setClass(getApplicationContext(), ImageActivity.class);
					i.putExtra("imageq", play.get((int)_position).get("link").toString());
					startActivity(i);
				}
				else {
					
				}
			}
		});
		
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				imageview6.setVisibility(View.VISIBLE);
				imageview1.setVisibility(View.GONE);
				recyclerview1.setVisibility(View.GONE);
				listview3.setVisibility(View.GONE);
				linear11.setVisibility(View.VISIBLE);
				linear14.setVisibility(View.VISIBLE);
				s = new TimerTask() {
					@Override
					public void run() {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								//_roundImageView(imageview6, 30);
							}
						});
					}
				};
				_timer.schedule(s, (int)(100));
			}
		});
		
		linear3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_bottom();
			}
		});
		
		imageview2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_bottom();
			}
		});
		
		textview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_bottom();
			}
		});
		
		textview2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_bottom();
			}
		});

		imageview4.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (raone.isPlaying()) {
					raone.pause();
					imageview4.setImageResource(R.drawable.ic_play_arrow);
					if (map.get((int)0).containsKey("text")) {
						t.cancel();
						progressbar1.setVisibility(View.GONE);
					}
					else {
						
					}
				}
				else {
					raone.start();
					imageview4.setImageResource(R.drawable.ic_pause);
					_mark3();
					_music1();
				}
			}
		});
	}
	
	private void initializeLogic() {
		pos = 0;
		tr = 0;
		progressbar1.setVisibility(View.GONE);
		recyclerview1.setLayoutManager(new LinearLayoutManager(this));
		new BackTask().execute(getIntent().getStringExtra("link"));
		progressbar2.setVisibility(View.VISIBLE);
		listview3.setVisibility(View.GONE);
		imageview6.setVisibility(View.GONE);
		linear11.setVisibility(View.GONE);
		linear14.setVisibility(View.GONE);
	}

	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	public void _extra () {
	}

	private class BackTask extends AsyncTask<String, Integer, String> {
		
		@Override
		
		protected void onPreExecute() {}
		
		
		protected String doInBackground(String... address) {
			
			String output = "";
			
			try {
				
				java.net.URL url = new java.net.URL(address[0]);
				
				java.io.BufferedReader in = new java.io.BufferedReader(new java.io.InputStreamReader(url.openStream()));
				
				String line;
				
				while ((line = in.readLine()) != null) {
					
					output += line;
					
				}
				
				in.close(); } catch (java.net.MalformedURLException e) {
				
				output = e.getMessage();
				
			} catch (java.io.IOException e) {
				
				output = e.getMessage();
				
			} catch (Exception e) {
				
				output = e.toString();
				
			}
			
			return output;
			
		}
		
		
		protected void onProgressUpdate(Integer... values) {}
		
		
		protected void onPostExecute(String s){
			str = s;
			map = new Gson().fromJson(str, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
			_me();
		}
	}
	
	
	public void _mark () {
		if ((pos < play.size()) || (pos == play.size())) {
			if (play.get((int)pos).containsKey("text")) {
				_mark1();
			}
			else {
				_mark2();
			}
		}
	}
	
	
	public void _mark1 () {
		if (play.get((int)pos).get("text").toString().equals("#")) {
			
		}
		else {
			if (play.get((int)pos).get("text").toString().equals("!")) {
				
			}
			else {
				recyclerview1.setAdapter(new Recyclerview1Adapter(play));
				if (pos == 0) {
					t = new TimerTask() {
						@Override
						public void run() {
							runOnUiThread(new Runnable() {
								@Override
								public void run() {
									listview3.setSelection((int)pos);
									listview3.smoothScrollToPosition((int)(pos));
									recyclerview1.smoothScrollToPosition((int)pos);
									 ((LinearLayoutManager) recyclerview1.getLayoutManager()).scrollToPositionWithOffset((int)pos, (int)0);
									pos++;
									_mark();
								}
							});
						}
					};
					_timer.schedule(t, (int)(Double.parseDouble(play.get((int)pos).get("time").toString())));
				}
				else {
					t = new TimerTask() {
						@Override
						public void run() {
							runOnUiThread(new Runnable() {
								@Override
								public void run() {
									listview3.setSelection((int)pos);
									listview3.smoothScrollToPosition((int)(pos));
									recyclerview1.smoothScrollToPosition((int)pos);
									 ((LinearLayoutManager) recyclerview1.getLayoutManager()).scrollToPositionWithOffset((int)pos, (int)0);
									pos++;
									_mark();
								}
							});
						}
					};
					_timer.schedule(t, (int)(Double.parseDouble(play.get((int)pos).get("time").toString()) - Double.parseDouble(play.get((int)pos - 1).get("time").toString())));
				}
			}
		}
	}


	public void _music () {
		currentfile = map.get((int)0).get("music").toString();
		raone = new MediaPlayer(); raone.setAudioStreamType(3); try { raone.setDataSource(currentfile); }catch (IllegalArgumentException e) { Toast.makeText(getApplicationContext(), "Unknown URL!", 1).show(); } catch (SecurityException e2) { Toast.makeText(getApplicationContext(), "Unknown URL!", 1).show(); } catch (IllegalStateException e3) { Toast.makeText(getApplicationContext(), "Unknown URL!", 1).show(); } catch (java.io.IOException e4) { e4.printStackTrace(); } try { raone.prepare(); } catch (IllegalStateException e5) { Toast.makeText(getApplicationContext(), "Unknown URL!", 1).show(); } catch (java.io.IOException e6) { Toast.makeText(getApplicationContext(), "Unknown URL!", 1).show(); }
		raone.start();
		if (map.get((int)0).containsKey("text")) {
			_mark();
		}
		else {
			
		}
		play1 = 1;
		song_duration = raone.getCurrentPosition();
		seekbar2.setProgress((int)raone.getCurrentPosition());
		seekbar2.setMax((int)raone.getDuration());
		textview4.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/sfl.ttf"), 0);
		textview3.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/sfl.ttf"), 0);
		textview6.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/sfl.ttf"), 0);
		t = new TimerTask() {
			@Override
			public void run() {
				runOnUiThread(new Runnable() {
					@Override
					public void run() {
						if (song_duration < raone.getDuration()) {
							song_duration = raone.getCurrentPosition();
							seekbar2.setProgress((int)raone.getCurrentPosition());
							textview6.setText(new DecimalFormat("00").format((raone.getCurrentPosition() / 1000) / 60).concat(":"));
							textview3.setText(new DecimalFormat("00").format((raone.getCurrentPosition() / 1000) % 60));
							textview4.setText("-".concat(new DecimalFormat("00").format((Double.parseDouble(String.valueOf((long)(raone.getCurrentPosition() - raone.getDuration())).replace("-", "")) / 1000) / 60).concat(":".concat(new DecimalFormat("00").format((Double.parseDouble(String.valueOf((long)(raone.getCurrentPosition() - raone.getDuration())).replace("-", "")) / 1000) % 60)))));
							textview4.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/sfl.ttf"), 0);
							textview3.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/sfl.ttf"), 0);
							textview6.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/sfl.ttf"), 0);

						}
						else {
							t.cancel();
						}
					}
				});
			}
		};
		_timer.scheduleAtFixedRate(t, (int)(50), (int)(50));
				{
					final Activity activity = MusicActivity.this;
					final Context context = activity.getApplicationContext();
					final int notificationId = 4;
					final String channelId = "4";
					final String channelName = "notif";

					new androidx.core.app.NotificationCompat.Builder(context, channelId){


						NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
						Intent intent335 = new Intent();
						public void create(){

							intent335.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
							PendingIntent pendingIntent = PendingIntent.getActivity(activity, 0, intent335, 0);

							if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
								NotificationChannel mChannel = new NotificationChannel(
										channelId, channelName, NotificationManager.IMPORTANCE_HIGH);
								notificationManager.createNotificationChannel(mChannel);
							}


							setSmallIcon(R.drawable.ic_pause);
							setContentTitle(map.get((int)0).get("name").toString().concat(" 🅴"));
							if (map.get((int)0).get("explicit").toString().equals("yes")) {
								setContentTitle(map.get((int)0).get("name").toString().concat(" 🅴"));
							}
							else {
								setContentTitle(map.get((int)0).get("name").toString());
							}
							if (map.get((int)0).containsKey("artist")) {
								setContentText(map.get((int)0).get("artist").toString());
							}
							else {
								setContentText(map.get((int)0).get("artists").toString());
							}
							setSubText(map.get((int)0).get("album").toString());
							setSound(Uri.parse(currentfile), AudioManager.STREAM_MUSIC);
							setStyle(new NotificationCompat.BigTextStyle());
							setAutoCancel(false);
							setOngoing(true);
							setContentIntent(pendingIntent);								   setContentIntent(TaskStackBuilder.create(context)
									.addNextIntent(intent335).getPendingIntent(0,PendingIntent.FLAG_UPDATE_CURRENT));


							notificationManager.notify(notificationId, this.build());

						}

					}.create();
				}
				
	}
	
	
	public void _mark2 () {
		if (pos == 0) {
			t = new TimerTask() {
				@Override
				public void run() {
					runOnUiThread(new Runnable() {
						@Override
						public void run() {
							listview3.setSelection((int)pos);
							listview3.smoothScrollToPosition((int)(pos));
							recyclerview1.smoothScrollToPosition((int)pos);
							 ((LinearLayoutManager) recyclerview1.getLayoutManager()).scrollToPositionWithOffset((int)pos, (int)0);
							progressbar1.setVisibility(View.VISIBLE);
							time = Double.parseDouble(play.get((int)pos).get("duration").toString());
							progressbar1.setMax((int)time);
							progressbar1.setProgress((int)0);
							s = new TimerTask() {
								@Override
								public void run() {
									runOnUiThread(new Runnable() {
										@Override
										public void run() {
											if ((progressbar1.getProgress() > time) || (progressbar1.getProgress() == time)) {
												progressbar1.setProgress((int)0);
												progressbar1.setVisibility(View.GONE);
												pos++;
												listview3.setSelection((int)pos);
												listview3.smoothScrollToPosition((int)(pos));
												recyclerview1.smoothScrollToPosition((int)pos);
												 ((LinearLayoutManager) recyclerview1.getLayoutManager()).scrollToPositionWithOffset((int)pos, (int)0);
												s.cancel();
												_mark();
											}
											else {
												progressbar1.setProgress((int)progressbar1.getProgress() + 50);
											}
										}
									});
								}
							};
							_timer.scheduleAtFixedRate(s, (int)(50), (int)(50));
						}
					});
				}
			};
			_timer.schedule(t, (int)(0));
		}
		else {
			t = new TimerTask() {
				@Override
				public void run() {
					runOnUiThread(new Runnable() {
						@Override
						public void run() {
							listview3.setSelection((int)pos);
							listview3.smoothScrollToPosition((int)(pos));
							recyclerview1.smoothScrollToPosition((int)pos);
							 ((LinearLayoutManager) recyclerview1.getLayoutManager()).scrollToPositionWithOffset((int)pos, (int)0);
							progressbar1.setVisibility(View.VISIBLE);
							time = Double.parseDouble(play.get((int)pos).get("duration").toString());
							progressbar1.setMax((int)time);
							progressbar1.setProgress((int)0);
							s = new TimerTask() {
								@Override
								public void run() {
									runOnUiThread(new Runnable() {
										@Override
										public void run() {
											if ((progressbar1.getProgress() > time) || (progressbar1.getProgress() == time)) {
												progressbar1.setProgress((int)0);
												progressbar1.setVisibility(View.GONE);
												pos++;
												listview3.setSelection((int)pos);
												listview3.smoothScrollToPosition((int)(pos));
												recyclerview1.smoothScrollToPosition((int)pos);
												 ((LinearLayoutManager) recyclerview1.getLayoutManager()).scrollToPositionWithOffset((int)pos, (int)0);
												s.cancel();
												_mark();
											}
											else {
												progressbar1.setProgress((int)progressbar1.getProgress() + 50);
											}
										}
									});
								}
							};
							_timer.scheduleAtFixedRate(s, (int)(50), (int)(50));
						}
					});
				}
			};
			_timer.schedule(t, (int)(Double.parseDouble(play.get((int)pos).get("time").toString()) - Double.parseDouble(play.get((int)pos - 1).get("time").toString())));
		}
	}
	
	
	public void _mark3 () {
		pos++;
		if (pos < play.size()) {
			if (play.get((int)pos).containsKey("text")) {
				if (!play.get((int)pos).get("text").toString().equals("#")) {
					if (!play.get((int)pos).get("text").toString().equals("!")) {
						t = new TimerTask() {
							@Override
							public void run() {
								runOnUiThread(new Runnable() {
									@Override
									public void run() {
										recyclerview1.smoothScrollToPosition((int)pos);
										 ((LinearLayoutManager) recyclerview1.getLayoutManager()).scrollToPositionWithOffset((int)pos, (int)0);
										pos++;
										_mark();
									}
								});
							}
						};
						_timer.schedule(t, (int)(Double.parseDouble(play.get((int)pos).get("time").toString()) - raone.getCurrentPosition()));
					}
					else {
						
					}
				}
				else {
					
				}
			}
			else {
				t = new TimerTask() {
					@Override
					public void run() {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								recyclerview1.smoothScrollToPosition((int)pos);
								 ((LinearLayoutManager) recyclerview1.getLayoutManager()).scrollToPositionWithOffset((int)pos, (int)0);
								progressbar1.setVisibility(View.VISIBLE);
								time = Double.parseDouble(play.get((int)pos).get("duration").toString());
								progressbar1.setMax((int)time);
								progressbar1.setProgress((int)0);
								s = new TimerTask() {
									@Override
									public void run() {
										runOnUiThread(new Runnable() {
											@Override
											public void run() {
												if (progressbar1.getProgress() == time) {
													progressbar1.setProgress((int)0);
													progressbar1.setVisibility(View.GONE);
													pos++;
													recyclerview1.smoothScrollToPosition((int)pos);
													 ((LinearLayoutManager) recyclerview1.getLayoutManager()).scrollToPositionWithOffset((int)pos, (int)0);
													s.cancel();
													_mark();
												}
												else {
													progressbar1.setProgress((int)progressbar1.getProgress() + 50);
												}
											}
										});
									}
								};
								_timer.scheduleAtFixedRate(s, (int)(50), (int)(50));
							}
						});
					}
				};
				_timer.schedule(t, (int)(Double.parseDouble(play.get((int)pos).get("time").toString()) - raone.getCurrentPosition()));
			}
		}
		else {
			
		}
	}
	
	
	public void _marquee (final TextView _textview, final String _text) {
		
		_textview.setText(_text);
		_textview.setSingleLine(true);
		_textview.setEllipsize(TextUtils.TruncateAt.MARQUEE);
		_textview.setSelected(true);
	}
	
	
	public void _view (final View _view, final String _color, final double _RT, final double _LT, final double _RB, final double _LB) {
		android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
		gd.setColor(Color.parseColor(_color));
		gd.setCornerRadii(new float[] { (float)_LT, (float)_LT, (float)_RT, (float)_RT, (float)_RB, (float)_RB, (float)_LB, (float)_LB });
		_view.setBackground(gd);
	}
	
	
	public void _mark4 () {
		if ((pos < play.size()) || (pos == play.size())) {
			if (play.get((int)pos).containsKey("text")) {
				raone.seekTo((int)(Double.parseDouble(play.get((int)pos).get("time").toString())));
				if (play.get((int)pos).get("text").toString().equals("#")) {
					
				}
				else {
					if (play.get((int)pos).get("text").toString().equals("!")) {
						
					}
					else {
						t = new TimerTask() {
							@Override
							public void run() {
								runOnUiThread(new Runnable() {
									@Override
									public void run() {
										listview3.setSelection((int)pos);
										listview3.smoothScrollToPosition((int)(pos));
										recyclerview1.smoothScrollToPosition((int)pos);
										 ((LinearLayoutManager) recyclerview1.getLayoutManager()).scrollToPositionWithOffset((int)pos, (int)0);
										pos++;
										_mark();
									}
								});
							}
						};
						_timer.schedule(t, (int)(0));
					}
				}
			}
			else {
				raone.seekTo((int)(Double.parseDouble(play.get((int)pos).get("time").toString())));
				t = new TimerTask() {
					@Override
					public void run() {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								listview3.setSelection((int)pos);
								listview3.smoothScrollToPosition((int)(pos));
								recyclerview1.smoothScrollToPosition((int)pos);
								 ((LinearLayoutManager) recyclerview1.getLayoutManager()).scrollToPositionWithOffset((int)pos, (int)0);
								progressbar1.setVisibility(View.VISIBLE);
								time = Double.parseDouble(play.get((int)pos).get("duration").toString());
								progressbar1.setMax((int)time);
								progressbar1.setProgress((int)0);
								s = new TimerTask() {
									@Override
									public void run() {
										runOnUiThread(new Runnable() {
											@Override
											public void run() {
												if ((progressbar1.getProgress() > time) || (progressbar1.getProgress() == time)) {
													progressbar1.setProgress((int)0);
													progressbar1.setVisibility(View.GONE);
													listview3.setSelection((int)pos);
													listview3.smoothScrollToPosition((int)(pos));
													recyclerview1.smoothScrollToPosition((int)pos);
													 ((LinearLayoutManager) recyclerview1.getLayoutManager()).scrollToPositionWithOffset((int)pos, (int)0);
													s.cancel();
													pos++;
													_mark();
												}
												else {
													progressbar1.setProgress((int)progressbar1.getProgress() + 50);
												}
											}
										});
									}
								};
								_timer.scheduleAtFixedRate(s, (int)(50), (int)(50));
							}
						});
					}
				};
				_timer.schedule(t, (int)(0));
			}
		}
	}
	
	
	public void _music1 () {
		song_duration = raone.getCurrentPosition();
		seekbar2.setProgress((int)raone.getCurrentPosition());
		seekbar2.setMax((int)raone.getDuration());
		textview4.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/sfl.ttf"), 0);
		textview3.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/sfl.ttf"), 0);
		textview6.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/sfl.ttf"), 0);
		t = new TimerTask() {
			@Override
			public void run() {
				runOnUiThread(new Runnable() {
					@Override
					public void run() {
						if (song_duration < raone.getDuration()) {
							song_duration = raone.getCurrentPosition();
							seekbar2.setProgress((int)raone.getCurrentPosition());
							textview6.setText(new DecimalFormat("00").format((raone.getCurrentPosition() / 1000) / 60).concat(":"));
							textview3.setText(new DecimalFormat("00").format((raone.getCurrentPosition() / 1000) % 60));
							textview4.setText("-".concat(new DecimalFormat("00").format((Double.parseDouble(String.valueOf((long)(raone.getCurrentPosition() - raone.getDuration())).replace("-", "")) / 1000) / 60).concat(":".concat(new DecimalFormat("00").format((Double.parseDouble(String.valueOf((long)(raone.getCurrentPosition() - raone.getDuration())).replace("-", "")) / 1000) % 60)))));
							textview4.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/sfl.ttf"), 0);
							textview3.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/sfl.ttf"), 0);
							textview6.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/sfl.ttf"), 0);

						}
						else {
							t.cancel();
						}
					}
				});
			}
		};
		_timer.scheduleAtFixedRate(t, (int)(50), (int)(50));
				{
					final Activity activity = MusicActivity.this;
					final Context context = activity.getApplicationContext();
					final int notificationId = 4;
					final String channelId = "4";
					final String channelName = "notif";

					new androidx.core.app.NotificationCompat.Builder(context, channelId){


						NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
						Intent intent335 = new Intent();
						public void create(){

							intent335.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
							PendingIntent pendingIntent = PendingIntent.getActivity(activity, 0, intent335, 0);

							if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
								NotificationChannel mChannel = new NotificationChannel(
										channelId, channelName, NotificationManager.IMPORTANCE_HIGH);
								notificationManager.createNotificationChannel(mChannel);
							}


							setSmallIcon(R.drawable.ic_pause);
							setContentTitle(map.get((int)0).get("name").toString().concat(" 🅴"));
							if (map.get((int)0).get("explicit").toString().equals("yes")) {
								setContentTitle(map.get((int)0).get("name").toString().concat(" 🅴"));
							}
							else {
								setContentTitle(map.get((int)0).get("name").toString());
							}
							if (map.get((int)0).containsKey("artist")) {
								setContentText(map.get((int)0).get("artist").toString());
							}
							else {
								setContentText(map.get((int)0).get("artists").toString());
							}
							setSubText(map.get((int)0).get("album").toString());
							setSound(Uri.parse(currentfile), AudioManager.STREAM_MUSIC);
							setStyle(new NotificationCompat.BigTextStyle());
							setAutoCancel(false);
							setOngoing(true);
							setContentIntent(pendingIntent);								   setContentIntent(TaskStackBuilder.create(context)
									.addNextIntent(intent335).getPendingIntent(0,PendingIntent.FLAG_UPDATE_CURRENT));


							notificationManager.notify(notificationId, this.build());

						}

					}.create();
				}

	}
	
	
	public void _me () {
		currentfile = map.get((int)0).get("music").toString();
		if (map.get((int)0).containsKey("text")) {
			text = map.get((int)0).get("text").toString();
			pos = 0;
			imageview6.setVisibility(View.GONE);
			imageview1.setVisibility(View.VISIBLE);
			recyclerview1.setVisibility(View.VISIBLE);
			listview3.setVisibility(View.VISIBLE);
			progressbar2.setVisibility(View.VISIBLE);
			linear11.setVisibility(View.GONE);
			linear14.setVisibility(View.GONE);
			_marquee(textview1, map.get((int)0).get("name").toString());
			if (map.get((int)0).containsKey("artist")) {
				_marquee(textview2, map.get((int)0).get("artist").toString());
			}
			else {
				_marquee(textview2, map.get((int)0).get("artists").toString());
			}
			Glide.with(getApplicationContext()).load(Uri.parse(map.get((int)0).get("image").toString())).into(imageview1);
			Glide.with(getApplicationContext()).load(Uri.parse(map.get((int)0).get("image").toString())).into(imageview6);
			textview1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/sfm.ttf"), 1);
			textview2.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/sfl.ttf"), 1);
			new BackTask1().execute(map.get((int)0).get("text").toString());
		}
		else {
			imageview6.setVisibility(View.VISIBLE);
			imageview1.setVisibility(View.GONE);
			recyclerview1.setVisibility(View.GONE);
			progressbar2.setVisibility(View.GONE);
			linear11.setVisibility(View.VISIBLE);
			linear14.setVisibility(View.VISIBLE);
			_marquee(textview1, map.get((int)0).get("name").toString());
			if (map.get((int)0).containsKey("artist")) {
				_marquee(textview2, map.get((int)0).get("artist").toString());
			}
			else {
				_marquee(textview2, map.get((int)0).get("artists").toString());
			}
			Glide.with(getApplicationContext()).load(Uri.parse(map.get((int)0).get("image").toString())).into(imageview1);
			Glide.with(getApplicationContext()).load(Uri.parse(map.get((int)0).get("image").toString())).into(imageview6);
			textview1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/sfm.ttf"), 1);
			textview2.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/sfl.ttf"), 1);
			_music();
			x = new TimerTask() {
				@Override
				public void run() {
					runOnUiThread(new Runnable() {
						@Override
						public void run() {
							//_roundImageView(imageview1, 15);
							//_roundImageView(imageview6, 30);
						}
					});
				}
			};
			_timer.schedule(x, (int)(1000));
		}
	}
	
	
	public void _extra1 () {
	}
	
	private class BackTask1 extends AsyncTask<String, Integer, String> {
		
		@Override
		
		protected void onPreExecute() {}
		
		
		protected String doInBackground(String... address) {
			
			String output = "";
			
			try {
				
				java.net.URL url = new java.net.URL(address[0]);
				
				java.io.BufferedReader in = new java.io.BufferedReader(new java.io.InputStreamReader(url.openStream()));
				
				String line;
				
				while ((line = in.readLine()) != null) {
					
					output += line;
					
				}
				
				in.close(); } catch (java.net.MalformedURLException e) {
				
				output = e.getMessage();
				
			} catch (java.io.IOException e) {
				
				output = e.getMessage();
				
			} catch (Exception e) {
				
				output = e.toString();
				
			}
			
			return output;
			
		}
		
		
		protected void onProgressUpdate(Integer... values) {}
		
		
		protected void onPostExecute(String s1){
			str1 = s1;
			play = new Gson().fromJson(str1, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
			_re();
		}
	}
	
	
	public void _CornerRadius (final View _view, final String _color, final double _RT, final double _LT, final double _RB, final double _LB) {
		android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
		gd.setColor(Color.parseColor(_color));
		gd.setCornerRadii(new float[] { (float)_LT, (float)_LT, (float)_RT, (float)_RT, (float)_RB, (float)_RB, (float)_LB, (float)_LB });
		_view.setBackground(gd);
	}
	
	
	public void _re () {
		recyclerview1.setAdapter(new Recyclerview1Adapter(play));
		listview3.setAdapter(new Listview3Adapter(play));
		((BaseAdapter)listview3.getAdapter()).notifyDataSetChanged();
		progressbar2.setVisibility(View.GONE);
		recyclerview1.setVisibility(View.VISIBLE);
		_music();
		x = new TimerTask() {
			@Override
			public void run() {
				runOnUiThread(new Runnable() {
					@Override
					public void run() {
						//_roundImageView(imageview1, 15);
					}
				});
			}
		};
		_timer.schedule(x, (int)(1000));
	}
	
	
	public void _bottom () {
		final com.google.android.material.bottomsheet.BottomSheetDialog bs_base = new com.google.android.material.bottomsheet.BottomSheetDialog(MusicActivity.this);
		bs_base.setCancelable(true);
		View layBase = getLayoutInflater().inflate(R.layout.bottom2, null);
		bs_base.setContentView(layBase);
		
		TextView name = (TextView)
		layBase.findViewById(R.id.name);
		_marquee(name, map.get((int)0).get("name").toString());
		name.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/sfm.ttf"), 1);
		
		TextView album = (TextView)
		layBase.findViewById(R.id.album);
		_marquee(album, map.get((int)0).get("album").toString());
		album.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/sfl.ttf"), 1);
		
		TextView artist = (TextView)
		layBase.findViewById(R.id.artist);
		if (map.get((int)0).containsKey("artist")) {
			_marquee(artist, map.get((int)0).get("artist").toString());
} else{
			_marquee(artist, map.get((int)0).get("artists").toString());
		}
		artist.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/sfl.ttf"), 0);
		
		TextView genre = (TextView)
		layBase.findViewById(R.id.genre);
		genre.setText(map.get((int)0).get("genre").toString().concat(" • ".concat(map.get((int)0).get("release").toString())));
		genre.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/sfl.ttf"), 0);
		
		ImageView image1 = (ImageView)
		layBase.findViewById(R.id.image1);
		Glide.with(getApplicationContext()).load(Uri.parse(map.get((int)0).get("image").toString())).into(image1);
		
		TextView lyricst = (TextView)
		layBase.findViewById(R.id.lyricst);
		
		ImageView lyricsi = (ImageView)
		layBase.findViewById(R.id.lyricsi);
		
		LinearLayout lyricsl = (LinearLayout)
		layBase.findViewById(R.id.lyricsl);
		
		if (map.get((int)0).containsKey("lyrics")) {
			lyricst.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					final com.google.android.material.bottomsheet.BottomSheetDialog bs_base = new com.google.android.material.bottomsheet.BottomSheetDialog(MusicActivity.this);
					bs_base.setCancelable(true);
					View layBase = getLayoutInflater().inflate(R.layout.bottom, null);
					bs_base.setContentView(layBase);
					
					TextView text = (TextView)
					layBase.findViewById(R.id.text);
					text.setText(map.get((int)0).get("lyrics").toString());
					text.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/sfl.ttf"), 0);
					
					TextView about = (TextView)
					layBase.findViewById(R.id.about);

					about.setText(map.get((int)0).get("name").toString());
					about.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/sfm.ttf"), 1);
					
					bs_base.show();
				}
			});
			lyricsi.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					final com.google.android.material.bottomsheet.BottomSheetDialog bs_base = new com.google.android.material.bottomsheet.BottomSheetDialog(MusicActivity.this);
					bs_base.setCancelable(true);
					View layBase = getLayoutInflater().inflate(R.layout.bottom, null);
					bs_base.setContentView(layBase);
					
					TextView text = (TextView)
					layBase.findViewById(R.id.text);
					text.setText(map.get((int)0).get("lyrics").toString());
					text.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/sfl.ttf"), 0);
					
					TextView about = (TextView)
					layBase.findViewById(R.id.about);

					about.setText(map.get((int)0).get("name").toString());
					about.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/sfm.ttf"), 1);
					
					bs_base.show();
				}
			});
			lyricsl.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					final com.google.android.material.bottomsheet.BottomSheetDialog bs_base = new com.google.android.material.bottomsheet.BottomSheetDialog(MusicActivity.this);
					bs_base.setCancelable(true);
					View layBase = getLayoutInflater().inflate(R.layout.bottom, null);
					bs_base.setContentView(layBase);
					
					TextView text = (TextView)
					layBase.findViewById(R.id.text);
					text.setText(map.get((int)0).get("lyrics").toString());
					text.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/sfl.ttf"), 0);
					
					TextView about = (TextView)
					layBase.findViewById(R.id.about);

					about.setText(map.get((int)0).get("name").toString());
					about.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/sfm.ttf"), 1);
					
					bs_base.show();
				}
			});
		}
		else {
			lyricsl.setVisibility(View.GONE);
		}
		lyricsi.setColorFilter(0xFF00BCD4, PorterDuff.Mode.MULTIPLY);
		TextView albumt = (TextView)
		layBase.findViewById(R.id.albumt);
		
		ImageView albumi = (ImageView)
		layBase.findViewById(R.id.albumi);
		
		LinearLayout albuml = (LinearLayout)
		layBase.findViewById(R.id.albuml);
		
		albumi.setColorFilter(0xFF00BCD4, PorterDuff.Mode.MULTIPLY);
		albumi.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setClass(getApplicationContext(), AlbumActivity.class);
				i.putExtra("link", map.get((int)0).get("alburi").toString());
				i.putExtra("songs", map.get((int)0).get("songs").toString());
				startActivity(i);
			}
		});
		albumt.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setClass(getApplicationContext(), AlbumActivity.class);
				i.putExtra("link", map.get((int)0).get("alburi").toString());
				i.putExtra("songs", map.get((int)0).get("songs").toString());
				startActivity(i);
			}
		});
		albuml.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setClass(getApplicationContext(), AlbumActivity.class);
				i.putExtra("link", map.get((int)0).get("alburi").toString());
				i.putExtra("songs", map.get((int)0).get("songs").toString());
				startActivity(i);
			}
		});
		TextView artistt = (TextView)
		layBase.findViewById(R.id.artistt);
		
		ImageView artisti = (ImageView)
		layBase.findViewById(R.id.artisti);
		
		LinearLayout artistl = (LinearLayout)
		layBase.findViewById(R.id.artistl);
		
		if (map.get((int)0).containsKey("artist")) {
			artisti.setImageResource(R.drawable.ic_timer_auto);
			artistt.setText("Go to Artist");
			artisti.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					i.setClass(getApplicationContext(), ArtistActivity.class);
					i.putExtra("link", map.get((int)0).get("arturi").toString());
					i.putExtra("albums", map.get((int)0).get("albums").toString());
					startActivity(i);
				}
			});
			artistt.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					i.setClass(getApplicationContext(), ArtistActivity.class);
					i.putExtra("link", map.get((int)0).get("arturi").toString());
					i.putExtra("albums", map.get((int)0).get("albums").toString());
					startActivity(i);
				}
			});
			artistl.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					i.setClass(getApplicationContext(), ArtistActivity.class);
					i.putExtra("link", map.get((int)0).get("arturi").toString());
					i.putExtra("albums", map.get((int)0).get("albums").toString());
					startActivity(i);
				}
			});
		}
		if (map.get((int)0).containsKey("artists")) {
			artisti.setImageResource(R.drawable.ic_people);
			artistt.setText("Go to Artists");
			new BackTask2().execute(map.get((int)0).get("artists").toString());
			artisti.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					
				}
			});
			artistt.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					
				}
			});
			artistl.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					
				}
			});
		}
		artisti.setColorFilter(0xFF00BCD4, PorterDuff.Mode.MULTIPLY);
		TextView downloadt = (TextView)
		layBase.findViewById(R.id.downloadt);
		
		ImageView downloadi = (ImageView)
		layBase.findViewById(R.id.downloadi);
		
		LinearLayout downloadl = (LinearLayout)
		layBase.findViewById(R.id.downloadl);
		
		downloadi.setColorFilter(0xFF00BCD4, PorterDuff.Mode.MULTIPLY);
		bs_base.show();
	}
	
	
	public void _roundImageView (final ImageView _Imageview, final double _round) {
		Bitmap bm = ((android.graphics.drawable.BitmapDrawable)_Imageview.getDrawable()).getBitmap();
		
		_Imageview.setImageBitmap(getRoundedCornerBitmap(bm, ((int)_round)));
		
	}
	public static Bitmap getRoundedCornerBitmap(Bitmap bitmap, int pixels) {
		Bitmap output = Bitmap.createBitmap(bitmap.getWidth(), bitmap.getHeight(), Bitmap.Config.ARGB_8888);
		Canvas canvas = new Canvas(output);
		final int color = 0xff424242;
		final Paint paint = new Paint();
		final Rect rect = new Rect(0, 0, bitmap.getWidth(), bitmap.getHeight());
		final RectF rectF = new RectF(rect);
		final float roundPx = pixels;
		paint.setAntiAlias(true);
		canvas.drawARGB(0, 0, 0, 0);
		paint.setColor(color);
		canvas.drawRoundRect(rectF, roundPx, roundPx, paint); 
		paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN)); 
		canvas.drawBitmap(bitmap, rect, rect, paint);
		return output;
	}
	
	
	public void _extra2 () {
	}
	
	private class BackTask2 extends AsyncTask<String, Integer, String> {
		
		@Override
		
		protected void onPreExecute() {}
		
		
		protected String doInBackground(String... address) {
			
			String output = "";
			
			try {
				
				java.net.URL url = new java.net.URL(address[0]);
				
				java.io.BufferedReader in = new java.io.BufferedReader(new java.io.InputStreamReader(url.openStream()));
				
				String line;
				
				while ((line = in.readLine()) != null) {
					
					output += line;
					
				}
				
				in.close(); } catch (java.net.MalformedURLException e) {
				
				output = e.getMessage();
				
			} catch (java.io.IOException e) {
				
				output = e.getMessage();
				
			} catch (Exception e) {
				
				output = e.toString();
				
			}
			
			return output;
			
		}
		
		
		protected void onProgressUpdate(Integer... values) {}
		
		
		protected void onPostExecute(String s2){
			str2 = s2;
			artists = new Gson().fromJson(str2, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
		}
	}
	
	
	public class Listview3Adapter extends BaseAdapter {
		ArrayList<HashMap<String, Object>> _data;
		public Listview3Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = (LayoutInflater)getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.text, null);
			}
			
			final LinearLayout linear1 = (LinearLayout) _view.findViewById(R.id.linear1);
			final LinearLayout edit = (LinearLayout) _view.findViewById(R.id.edit);
			final LinearLayout text1 = (LinearLayout) _view.findViewById(R.id.text1);
			final LinearLayout progress = (LinearLayout) _view.findViewById(R.id.progress);
			final LinearLayout written = (LinearLayout) _view.findViewById(R.id.written);
			final TextView text = (TextView) _view.findViewById(R.id.text);
			final TextView translate = (TextView) _view.findViewById(R.id.translate);
			final ProgressBar progressbar1 = (ProgressBar) _view.findViewById(R.id.progressbar1);
			final TextView written_by = (TextView) _view.findViewById(R.id.written_by);
			final TextView edit1 = (TextView) _view.findViewById(R.id.edit1);
			
			written.setVisibility(View.GONE);
			edit.setVisibility(View.GONE);
			if (play.get((int)_position).containsKey("text")) {
				if (play.get((int)_position).get("text").toString().equals("!")) {
					progress.setVisibility(View.GONE);
					text1.setVisibility(View.GONE);
					progress.setVisibility(View.GONE);
					edit.setVisibility(View.VISIBLE);
					edit1.setText("Edit by ".concat(play.get((int)_position).get("edit").toString()).concat("\nclick to view changelog".concat(play.get((int)_position).get("edit1").toString())));
				}
				else {
					if (play.get((int)_position).get("text").toString().equals("#")) {
						written.setVisibility(View.VISIBLE);
						text1.setVisibility(View.GONE);
						progress.setVisibility(View.GONE);
						edit.setVisibility(View.GONE);
						written_by.setText("Written by: ".concat(play.get((int)_position).get("written_by").toString()));
						written_by.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/sfl.ttf"), 0);
					}
					else {
						text.setText(play.get((int)_position).get("text").toString());
						text.setTextSize(TypedValue.COMPLEX_UNIT_SP, 35);
						text.setTextColor(0xFFBDBDBD);
						text.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/sfm.ttf"), 1);
						written.setVisibility(View.GONE);
						progress.setVisibility(View.GONE);
						edit.setVisibility(View.GONE);
					}
				}
			}
			else {
				written.setVisibility(View.GONE);
				edit.setVisibility(View.GONE);
				progress.setVisibility(View.GONE);
				linear1.setVisibility(View.GONE);
				text1.setVisibility(View.GONE);
			}
			
			return _view;
		}
	}
	
	public class Recyclerview1Adapter extends RecyclerView.Adapter<Recyclerview1Adapter.ViewHolder> {
		ArrayList<HashMap<String, Object>> _data;
		public Recyclerview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
			LayoutInflater _inflater = (LayoutInflater)getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View _v = _inflater.inflate(R.layout.text, null);
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			_v.setLayoutParams(_lp);
			return new ViewHolder(_v);
		}
		
		@Override
		public void onBindViewHolder(ViewHolder _holder, final int _position) {
			View _view = _holder.itemView;
			
			final LinearLayout linear1 = (LinearLayout) _view.findViewById(R.id.linear1);
			final LinearLayout edit = (LinearLayout) _view.findViewById(R.id.edit);
			final LinearLayout text1 = (LinearLayout) _view.findViewById(R.id.text1);
			final LinearLayout progress = (LinearLayout) _view.findViewById(R.id.progress);
			final LinearLayout written = (LinearLayout) _view.findViewById(R.id.written);
			final TextView text = (TextView) _view.findViewById(R.id.text);
			final TextView translate = (TextView) _view.findViewById(R.id.translate);
			final ProgressBar progressbar1 = (ProgressBar) _view.findViewById(R.id.progressbar1);
			final TextView written_by = (TextView) _view.findViewById(R.id.written_by);
			final TextView edit1 = (TextView) _view.findViewById(R.id.edit1);
			
			written.setVisibility(View.GONE);
			edit.setVisibility(View.GONE);
			if (play.get((int)_position).containsKey("text")) {
				if (play.get((int)_position).get("text").toString().equals("!")) {
					progress.setVisibility(View.GONE);
					text1.setVisibility(View.GONE);
					progress.setVisibility(View.GONE);
					edit.setVisibility(View.VISIBLE);
					edit1.setText("Edit by ".concat(play.get((int)_position).get("edit").toString()).concat("\nclick to view changelog".concat(play.get((int)_position).get("edit1").toString())));
				}
				else {
					if (play.get((int)_position).get("text").toString().equals("#")) {
						written.setVisibility(View.VISIBLE);
						text1.setVisibility(View.GONE);
						progress.setVisibility(View.GONE);
						edit.setVisibility(View.GONE);
						written_by.setText("Written by: ".concat(play.get((int)_position).get("written_by").toString()));
						written_by.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/sfl.ttf"), 0);
					}
					else {
						text.setText(play.get((int)_position).get("text").toString());
						text.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/sfm.ttf"), 1);
						written.setVisibility(View.GONE);
						progress.setVisibility(View.GONE);
						edit.setVisibility(View.GONE);
						text.setTextSize(TypedValue.COMPLEX_UNIT_SP, 35);
						text.setTextColor(0xFFE0E0E0);
						if (play.get((int)_position).containsKey("translate")) {
							if (tr == 0) {
								translate.setVisibility(View.GONE);
							}
							else {
								translate.setVisibility(View.VISIBLE);
								translate.setText(play.get((int)_position).get("translate").toString());
								translate.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/sfl.ttf"), 0);
							}
						}
						if ((pos - 1) == _position) {
							text.setTextSize(TypedValue.COMPLEX_UNIT_SP, 36);
							text.setTextColor(0xFF80deea);
							translate.setTextSize(TypedValue.COMPLEX_UNIT_SP, 26);
							translate.setTextColor(0xFF80deea);
						}
						else {
							text.setTextSize(TypedValue.COMPLEX_UNIT_SP, 35);
							text.setTextColor(0xFFE0E0E0);
							translate.setTextSize(TypedValue.COMPLEX_UNIT_SP, 25);
							translate.setTextColor(0xFFE0E0E0);
						}
					}
				}
			}
			else {
				written.setVisibility(View.GONE);
				edit.setVisibility(View.GONE);
				progress.setVisibility(View.GONE);
				linear1.setVisibility(View.GONE);
				text1.setVisibility(View.GONE);
			}
			edit1.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					i.setClass(getApplicationContext(), ImageActivity.class);
					i.putExtra("imageq", play.get((int)_position).get("link").toString());
					startActivity(i);
				}
			});
			text1.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					if (play.get((int)pos).containsKey("duration")) {
						progressbar1.setVisibility(View.GONE);
						progressbar1.setProgress((int)0);
						s.cancel();
					}
					else {
						
					}
					t.cancel();
					pos = _position;
					_mark4();
				}
			});
		}
		
		@Override
		public int getItemCount() {
			return _data.size();
		}
		
		public class ViewHolder extends RecyclerView.ViewHolder{
			public ViewHolder(View v){
				super(v);
			}
		}
		
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
