package ru.kartofan.theme.music.app;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.os.*;
import android.view.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.text.*;
import android.util.*;

import java.util.*;
import java.util.HashMap;
import java.util.ArrayList;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.BaseAdapter;
import android.content.Intent;
import android.net.Uri;
import java.util.Timer;
import java.util.TimerTask;
import android.view.View;
import android.widget.AdapterView;
import android.graphics.Typeface;
import com.bumptech.glide.Glide;
import com.google.android.material.appbar.SubtitleCollapsingToolbarLayout;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import androidx.appcompat.widget.Toolbar;

public class ArtistActivity extends  AppCompatActivity  {
	private Timer _timer = new Timer();
	
	private double height = 0;
	private double width = 0;
	private String str = "";
	private HashMap<String, Object> map1 = new HashMap<>();
	private String s = "";
	private String str1 = "";
	private String about = "";
	private String abt = "";
	
	private ArrayList<HashMap<String, Object>> map = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> play = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> info = new ArrayList<>();
	
	private LinearLayout linear1;
	private TextView textview12;
	private LinearLayout linear9;
	private LinearLayout linear2;
	private ImageView imageview1;
	private TextView textview1;
	private ListView listview1;
	private LinearLayout linear5;
	private LinearLayout linear3;
	private LinearLayout linear6;
	private LinearLayout linear7;
	private LinearLayout linear8;
	private TextView textview2;
	private TextView textview3;
	private TextView textview6;
	private TextView textview7;
	private TextView textview8;
	private TextView textview9;
	private TextView textview10;
	private TextView textview11;
	private SharedPreferences sp;
	
	private Intent i = new Intent();
	private TimerTask t;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.artist);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		textview12 = (TextView) findViewById(R.id.textview12);
		linear9 = (LinearLayout) findViewById(R.id.linear9);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		imageview1 = (ImageView) findViewById(R.id.imageview1);
		textview1 = (TextView) findViewById(R.id.textview1);
		listview1 = (ListView) findViewById(R.id.listview1);
		linear5 = (LinearLayout) findViewById(R.id.linear5);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		linear6 = (LinearLayout) findViewById(R.id.linear6);
		linear7 = (LinearLayout) findViewById(R.id.linear7);
		linear8 = (LinearLayout) findViewById(R.id.linear8);
		textview2 = (TextView) findViewById(R.id.textview2);
		textview3 = (TextView) findViewById(R.id.textview3);
		textview6 = (TextView) findViewById(R.id.textview6);
		textview7 = (TextView) findViewById(R.id.textview7);
		textview8 = (TextView) findViewById(R.id.textview8);
		textview9 = (TextView) findViewById(R.id.textview9);
		textview10 = (TextView) findViewById(R.id.textview10);
		textview11 = (TextView) findViewById(R.id.textview11);
		sp = getSharedPreferences("sp", Activity.MODE_PRIVATE);
		
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setClass(getApplicationContext(), ImageActivity.class);
				i.putExtra("imageq", map.get((int)0).get("image").toString());
				startActivity(i);
			}
		});
		
		listview1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				if (play.get((int)_position).containsKey("link")) {
					i.setClass(getApplicationContext(), AlbumActivity.class);
					i.putExtra("link", play.get((int)_position).get("link").toString());
					i.putExtra("songs", play.get((int)_position).get("songs").toString());
					startActivity(i);
				}
				else {
					com.google.android.material.snackbar.Snackbar.make(listview1, "This album will be added soon!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("ok", new View.OnClickListener(){
						@Override
						public void onClick(View _view) {
							 
						}
					}).show();
				}
			}
		});
		
		textview3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (about.length() > 110) {
					final com.google.android.material.bottomsheet.BottomSheetDialog bs_base = new com.google.android.material.bottomsheet.BottomSheetDialog(ArtistActivity.this);
					bs_base.setCancelable(true);
					View layBase = getLayoutInflater().inflate(R.layout.bottom, null);
					bs_base.setContentView(layBase);
					TextView text = (TextView)
					layBase.findViewById(R.id.text);
					text.setText(map.get((int)0).get("about").toString());
					text.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/sfl.ttf"), Typeface.NORMAL);
					
					TextView about = (TextView)
					layBase.findViewById(R.id.about);

					about.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/sfm.ttf"), Typeface.BOLD);
					
					bs_base.show();
				}
				else {
					
				}
			}
		});
	}
	
	private void initializeLogic() {

		textview2.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/sfm.ttf"), Typeface.BOLD);
		textview6.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/sfm.ttf"), Typeface.BOLD);
		textview8.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/sfm.ttf"), Typeface.BOLD);
		textview10.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/sfm.ttf"), Typeface.BOLD);
		new BackTask().execute(getIntent().getStringExtra("link"));
		new BackTask1().execute(getIntent().getStringExtra("albums"));
		listview1.setVisibility(View.INVISIBLE);
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}

	@Override
	public void onBackPressed() {
		finish();
	}

	public void _extra () {
	}
	
	private class BackTask extends AsyncTask<String, Integer, String> {
		
		@Override
		
		protected void onPreExecute() {}
		
		
		protected String doInBackground(String... address) {
			
			String output = "";
			
			try {
				
				java.net.URL url = new java.net.URL(address[0]);
				
				java.io.BufferedReader in = new java.io.BufferedReader(new java.io.InputStreamReader(url.openStream()));
				
				String line;
				
				while ((line = in.readLine()) != null) {
					
					output += line;
					
				}
				
				in.close(); } catch (java.net.MalformedURLException e) {
				
				output = e.getMessage();
				
			} catch (java.io.IOException e) {
				
				output = e.getMessage();
				
			} catch (Exception e) {
				
				output = e.toString();
				
			}
			
			return output;
			
		}
		
		
		protected void onProgressUpdate(Integer... values) {}
		
		
		protected void onPostExecute(String s){
			str = s;
			map = new Gson().fromJson(str, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
			_text();
		}
	}

	public void _text () {
		Glide.with(getApplicationContext()).load(Uri.parse(map.get((int)0).get("image").toString())).into(imageview1);
		if (sp.getString("video", "").equals("yes")) {
			Glide.with(getApplicationContext()).load(Uri.parse(map.get((int)0).get("video").toString())).into(imageview1);
		}
		_marquee(textview1, map.get((int)0).get("name").toString());
		textview1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/sfm.ttf"), 1);
		Toolbar toolbar = findViewById(R.id.toolbar);
		setSupportActionBar(toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_arrow_back);
		final SubtitleCollapsingToolbarLayout subtitleCollapsingToolbarLayout = findViewById(R.id.toolbar_layout);
		subtitleCollapsingToolbarLayout.setTitle(map.get((int)0).get("name").toString());
		if (map.get((int)0).containsKey("about")) {
			about = map.get((int)0).get("about").toString();
			if (about.length() > 110) {
				_marquee1(textview3, map.get((int)0).get("about").toString());
			}
			else {
				textview3.setText(map.get((int)0).get("about").toString());
			}
			textview3.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/sfl.ttf"), 0);
		}
		else {
			linear2.setVisibility(View.GONE);
		}
		if (map.get((int)0).containsKey("hometown")) {
			textview7.setText(map.get((int)0).get("hometown").toString());
			textview7.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/sfl.ttf"), 0);
		}
		else {
			if (map.get((int)0).containsKey("from")) {
				textview6.setText("FROM");
				textview6.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/sfm.ttf"), 1);
				textview7.setText(map.get((int)0).get("from").toString());
				textview7.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/sfl.ttf"), 0);
			}
			else {
				linear6.setVisibility(View.GONE);
			}
		}
		if (map.get((int)0).containsKey("born")) {
			textview9.setText(map.get((int)0).get("born").toString());
			textview9.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/sfl.ttf"), 0);
		}
		else {
			if (map.get((int)0).containsKey("formed")) {
				textview8.setText("FORMED");
				textview8.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/sfm.ttf"), 1);
				textview9.setText(map.get((int)0).get("formed").toString());
				textview9.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/sfl.ttf"), 0);
			}
			else {
				linear7.setVisibility(View.GONE);
			}
		}
		if (map.get((int)0).containsKey("genre")) {
			textview11.setText(map.get((int)0).get("genre").toString());
			textview11.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/sfl.ttf"), 0);
		}
		else {
			linear8.setVisibility(View.GONE);
		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		MenuInflater inflater = getMenuInflater();
		inflater.inflate(R.menu.artist, menu);
		return true;
	}
	@Override
	public boolean onOptionsItemSelected(@NonNull MenuItem item){
		if (item.getItemId()==android.R.id.home){
			finish();
		}
		return super.onOptionsItemSelected(item);
	}

	public void _marquee (final TextView _textview, final String _text) {
		
		_textview.setText(_text);
		_textview.setSingleLine(true);
		_textview.setEllipsize(TextUtils.TruncateAt.MARQUEE);
		_textview.setSelected(true);
	}

	public void _marquee1 (final TextView _textview, final String _text) {

		_textview.setText(_text);
		_textview.setMaxLines(2);
		_textview.setEllipsize(TextUtils.TruncateAt.END);
		_textview.setSelected(true);
	}
	
	public void _extra1 () {
	}
	
	private class BackTask1 extends AsyncTask<String, Integer, String> {
		
		@Override
		
		protected void onPreExecute() {}
		
		
		protected String doInBackground(String... address) {
			
			String output = "";
			
			try {
				
				java.net.URL url = new java.net.URL(address[0]);
				
				java.io.BufferedReader in = new java.io.BufferedReader(new java.io.InputStreamReader(url.openStream()));
				
				String line;
				
				while ((line = in.readLine()) != null) {
					
					output += line;
					
				}
				
				in.close(); } catch (java.net.MalformedURLException e) {
				
				output = e.getMessage();
				
			} catch (java.io.IOException e) {
				
				output = e.getMessage();
				
			} catch (Exception e) {
				
				output = e.toString();
				
			}
			
			return output;
			
		}
		
		
		protected void onProgressUpdate(Integer... values) {}
		
		
		protected void onPostExecute(String s1){
			str1 = s1;
			play = new Gson().fromJson(str1, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
			listview1.setAdapter(new Listview1Adapter(play));
			_ViewSetHeight(listview1, play.size() * SketchwareUtil.getDip(getApplicationContext(), (int)(77)));
			((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
			t = new TimerTask() {
				@Override
				public void run() {
					runOnUiThread(new Runnable() {
						@Override
						public void run() {
							listview1.setVisibility(View.VISIBLE);
						}
					});
				}
			};
			_timer.schedule(t, (int)(600));
		}
	}
	
	
	public void _roundImageView (final ImageView _Imageview, final double _round) {
		Bitmap bm = ((android.graphics.drawable.BitmapDrawable)_Imageview.getDrawable()).getBitmap();
		
		_Imageview.setImageBitmap(getRoundedCornerBitmap(bm, ((int)_round)));
		
	}
	public static Bitmap getRoundedCornerBitmap(Bitmap bitmap, int pixels) {
		Bitmap output = Bitmap.createBitmap(bitmap.getWidth(), bitmap.getHeight(), Bitmap.Config.ARGB_8888);
		Canvas canvas = new Canvas(output);
		final int color = 0xff424242;
		final Paint paint = new Paint();
		final Rect rect = new Rect(0, 0, bitmap.getWidth(), bitmap.getHeight());
		final RectF rectF = new RectF(rect);
		final float roundPx = pixels;
		paint.setAntiAlias(true);
		canvas.drawARGB(0, 0, 0, 0);
		paint.setColor(color);
		canvas.drawRoundRect(rectF, roundPx, roundPx, paint); 
		paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN)); 
		canvas.drawBitmap(bitmap, rect, rect, paint);
		return output;
	}

	private void _ViewSetHeight(final View _view, final double _num) {
		_view.getLayoutParams().height=(int)(_num);
	}


	public class Listview1Adapter extends BaseAdapter {
		ArrayList<HashMap<String, Object>> _data;
		public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = (LayoutInflater)getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.playlists, null);
			}
			
			final LinearLayout linear1 = (LinearLayout) _view.findViewById(R.id.linear1);
			final ImageView imageview1 = (ImageView) _view.findViewById(R.id.imageview1);
			final ImageView explicit = (ImageView) _view.findViewById(R.id.explicit);
			final LinearLayout linear2 = (LinearLayout) _view.findViewById(R.id.linear2);
			final TextView Name = (TextView) _view.findViewById(R.id.Name);
			final TextView album = (TextView) _view.findViewById(R.id.album);
			final TextView Release = (TextView) _view.findViewById(R.id.Release);
			
			_marquee(Name, play.get((int)_position).get("name").toString());
			if (play.get((int)_position).containsKey("image")) {
				Glide.with(getApplicationContext()).load(Uri.parse(play.get((int)_position).get("image").toString())).into(imageview1);
			}
			if (play.get((int)_position).containsKey("album") && play.get((int)_position).containsKey("time")) {
				album.setText(play.get((int)_position).get("album").toString().concat(" • ".concat(play.get((int)_position).get("time").toString())));
			}
			if (play.get((int)_position).containsKey("release")) {
				Release.setText(play.get((int)_position).get("release").toString());
			}
			if (play.get((int)_position).get("explicit").toString().equals("yes")) {
				explicit.setVisibility(View.VISIBLE);
			}
			else {
				explicit.setVisibility(View.GONE);
			}
			Name.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/sfm.ttf"), Typeface.BOLD);
			album.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/sfl.ttf"), Typeface.NORMAL);
			Release.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/sfl.ttf"), Typeface.NORMAL);
			t = new TimerTask() {
				@Override
				public void run() {
					runOnUiThread(new Runnable() {
						@Override
						public void run() {
							//_roundImageView(imageview1, 15);
						}
					});
				}
			};
			_timer.schedule(t, (int)(500));
			
			return _view;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
